<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\peralatankeamanan;
use Illuminate\Http\Request;
use App\Models\bahanbangunan;
use App\Models\Komentar;
use App\Models\peralatankonstruksi;
use App\Models\peralatanlistrik;
use App\Models\rumahtangga;
use App\Models\peralatantanaman;

class BahanbangunanController extends Controller
{
    public function index()
    { 
        $bahanbangunan = bahanbangunan::all();
        return view('admin.bahanbangunan.bahanbangunan', compact('bahanbangunan'));
    }

    public function create()
    {
        return view('admin.bahanbangunan.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'string|max:255',
            'harga' => 'integer',
            'stok' => 'integer',
            'description' => 'nullable|string',
            'image' => 'nullable|image|mimes:jpg,png,jpeg|max:2048',
        ]);

        $bahanbangunan = new bahanbangunan;
        $bahanbangunan->name = $request->name;
        $bahanbangunan->description = $request->description;
        $bahanbangunan->harga = $request->harga;
        $bahanbangunan->stok = $request->stok;

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $image_name = time().'.'.$image->getClientOriginalExtension();
            $destination_path = public_path('/images/bahanbangunan');
            $image->move($destination_path, $image_name);
            $bahanbangunan->image = $image_name;
        }

        $bahanbangunan->save();
        return redirect()->route('admin.bahanbangunan.bahanbangunan')->with('success', 'Bahan bangunan has been created successfully');
    }

    public function edit(bahanbangunan $bahanbangunan)
    {
        return view('admin.bahanbangunan.edit', compact('bahanbangunan'));
    }

    public function update(Request $request, bahanbangunan $bahanbangunan)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'harga' => 'required|integer',
            'stok' => 'required|integer',
            'description' => 'nullable|string',
            'image' => 'nullable|image|mimes:jpg,png,jpeg|max:2048',
        ]);

        $bahanbangunan->name = $request->name;
        $bahanbangunan->harga = $request->harga;
        $bahanbangunan->stok = $request->stok;
        $bahanbangunan->description = $request->description;

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $image_name = time().'.'.$image->getClientOriginalExtension();
            $destination_path = public_path('/images/bahanbangunan');
            $image->move($destination_path, $image_name);
            $bahanbangunan->image = $image_name;
        }

        $bahanbangunan->save();
        return redirect()->route('admin.bahanbangunan.bahanbangunan')->with('success', 'bahanbangunan has been updated successfully');
    }

    public function destroy(bahanbangunan $bahanbangunan)
    {
        $bahanbangunan->delete();
        return redirect()->route('admin.bahanbangunan.bahanbangunan')->with('success', 'bahanbangunan has been deleted successfully');
    }

    public function show($id)
{
    $bahanbangunan = BahanBangunan::find($id);
    $komentar = null;
if ($bahanbangunan) {
    $komentar = $bahanbangunan->komentar;
}

    return view('client.bahanbangunan.show', compact('bahanbangunan', 'komentar', 'rating'));

}
public function storeKomentar(Request $request, $id)
{
    // Validasi input pengguna
    $request->validate([
        'komentar' => 'required',
        'rating' => 'required|integer|min:1|max:5',
    ]);

    // Cari produk berdasarkan ID
    $bahanbangunan = BahanBangunan::find($id);
    $peralatanlistrik = peralatanlistrik::find($id);
    $peralatankeamanan = peralatankeamanan::find($id);
    $rumahtangga = rumahtangga::find($id);
    $peralatankonstruksi = peralatankonstruksi::find($id);
    $peralatantanaman = Peralatantanaman::find($id);

    // Buat instance komentar
    $komentar = new Komentar();
    $komentar->komentar = $request->input('komentar');

    // Tentukan relasi dengan produk yang sesuai
    if ($bahanbangunan) {
        $bahanbangunan->komentar()->save($komentar);
    } elseif ($peralatanlistrik) {
        $peralatanlistrik->komentar()->save($komentar);
    } elseif ($peralatankeamanan) {
        $peralatankeamanan->komentar()->save($komentar);
    } elseif ($rumahtangga) {
        $rumahtangga->komentar()->save($komentar);
    } elseif ($peralatankonstruksi) {
        $peralatankonstruksi->komentar()->save($komentar);
    } elseif ($peralatantanaman) {
        $peralatantanaman->komentar()->save($komentar);
    }

    return redirect()->back()->with('success', 'Komentar berhasil disimpan.');
}

    
}
