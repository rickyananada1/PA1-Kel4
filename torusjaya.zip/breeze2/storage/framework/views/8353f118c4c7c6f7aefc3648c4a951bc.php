
<?php $__env->startSection('title', 'Detail Bahan Bangunan'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('client.section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="latest-podcast-section section-padding pb-0" id="section_2">
            <div class="container">
                <div class="row justify-content-center">

                    <div class="col-lg-10 col-12">
                        <div class="section-title-wrap mb-5">
                            <h4 class="section-title">Detail Page</h4>
                        </div>

                        <div class="row">
                            <div class="col-lg-3 col-12">
                                <div class="custom-block-icon-wrap">
                                    <div class="custom-block-image-wrap custom-block-image-detail-page">
                                        <img src="<?php echo e(asset('images/bahanbangunan/'.$bahanbangunan->image)); ?>"
                                            class="custom-block-image img-fluid" alt="">
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-9 col-12">
                                <div class="custom-block-info">
                                    <div class="custom-block-top d-flex mb-1">
                                        <small class="ms-auto">Stok <span class="badge"><?php echo e($bahanbangunan->stok); ?></span></small>
                                    </div>

                                    <h2 class="mb-2"><?php echo e($bahanbangunan->name); ?></h2>

                                    <p><?php echo e($bahanbangunan->description); ?></p>

                                    <div
                                        class="profile-block profile-detail-block d-flex flex-wrap align-items-center mt-5">
                                        <div class="d-flex mb-3 mb-lg-0 mb-md-0">
                                            <?php
                                                $firstLetter = strtoupper(substr(Auth::user()->name, 0, 1));
                                            ?>
                                            <div class="profile-block-image img-fluid"
                                                style="background-color: #e9ecef; color: #000; text-align: center; font-size: 48px; width: 100px; height: 93px;">
                                                <?php echo e($firstLetter); ?>

                                            </div>
                                            <p><?php echo e(Auth::user()->name); ?></p>
                                        </div>


                                        <ul class="social-icon ms-lg-auto ms-md-auto">
                                            <li class="social-icon-item">
                                                <a href="#" class="social-icon-link bi-instagram"></a>
                                            </li>

                                            <li class="social-icon-item">
                                                <a href="#" class="social-icon-link bi-twitter"></a>
                                            </li>

                                            <li class="social-icon-item">
                                                <a href="#" class="social-icon-link bi-whatsapp"></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <form method="POST" action="<?php echo e(route('bahanbangunan.komentar.store', $bahanbangunan->id)); ?>">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="komentar">Komentar</label>
        <textarea class="form-control" name="komentar" id="komentar" rows="3" required></textarea>
    </div>
    </div>

    <button type="submit" class="btn btn-primary">Tambah Komentar</button>
</form>

                </div>
            </div>
        </section>
<?php
  $bahanbangunans = App\Models\bahanbangunan::latest()->get();
?>
        <section class="topics-section section-padding pb-0" id="section_3">
            <div class="container">
                <div class="row">
                  <div class="col-lg-12 col-12">
                    <div class="section-title-wrap mb-5">
                      <h4 class="section-title">Related Product</h4>
                    </div>
                  </div>
                  <?php $__currentLoopData = $bahanbangunans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                  <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                    <div class="custom-block custom-block-overlay">
                      <a href="<?php echo e(route('client.bahanbangunan.show', $item->id)); ?>" class="custom-block-image-wrap">
                                <img src="<?php echo e(asset('images/bahanbangunan/'.$item->image)); ?>"
                                    class="custom-block-image img-fluid" alt="">
                            </a>

                            <div class="custom-block-info custom-block-overlay-info">
                                <h5 class="mb-1">
                                    <a href="<?php echo e(route('client.bahanbangunan.show', $item->id)); ?>">
                                    <?php echo e($item->name); ?>

                                    Rp. <?php echo e(number_format($item->harga)); ?>

                                    </a>
                                </h5>

                                <p class="badge mb-0">Stok: <?php echo e($item->stok); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
<?php echo $__env->make('client.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('client.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\breeze2\resources\views/client/bahanbangunan/show.blade.php ENDPATH**/ ?>