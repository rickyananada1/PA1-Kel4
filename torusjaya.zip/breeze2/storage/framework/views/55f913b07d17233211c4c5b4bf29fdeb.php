
<?php $__env->startSection('title','User | Peralatan Keamanan'); ?>
<?php $__env->startSection('content'); ?>
<?php
  $peralatankeamanans = DB::table('peralatankeamanans')->get();
  ?>

  <div id="carouselExampleCaptions" class="carousel slide shadow bg-dark" data-bs-ride="carousel">
      <div class="carousel-inner ">
        <?php $__currentLoopData = $peralatankeamanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="carousel-item <?php if($loop->first): ?> active <?php endif; ?>">
          <br><br>
            <div class="slider-image text-center">
               <img src="<?php echo e(asset('images/alatkeamanan/'.$item->image)); ?>" class="d-inline-block border text-center rounded" alt="...">
            </div>
          </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
      </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
    <br><br>
</div>

<div class="container">
<h2>Peralatan Keamanan</h2>
<div class="row row-cols-1 row-cols-md-4 g-4 mt-2 shadow">
  <?php $__currentLoopData = $peralatankeamanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col">
    <div class="card h-100">
      <img src=" <?php echo e(asset('images/alatkeamanan/'.$item->image)); ?>" width="100%" height="150px" alt="...">
      <div class="card-body">
        <h5 class="card-title"><?php echo e($item->name); ?></h5>
        <p class="card-text"><?php echo e($item->description); ?></p>
      </div>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\breeze\resources\views/client/peralatankeamanan.blade.php ENDPATH**/ ?>