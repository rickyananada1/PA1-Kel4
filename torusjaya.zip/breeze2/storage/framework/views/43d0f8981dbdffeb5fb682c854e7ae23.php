

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Informasi dan Pengumuman</h3>
            <div class="card-tools">
                <a href="<?php echo e(route('admin.informasi.create')); ?>" class="btn btn-success btn-sm">Add New</a>
            </div>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $informasitoko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informasitoko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($informasitoko->id); ?></td>
                            <td><?php echo e($informasitoko->name); ?></td>
                            <td><?php echo e($informasitoko->description); ?></td>
                            <td> <?php if($informasitoko->image): ?>
                                    <img src="<?php echo e(asset('images/informasi/'.$informasitoko->image)); ?>" alt="<?php echo e($informasitoko->name); ?>" width="100">
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.informasi.edit', $informasitoko->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                <form action="<?php echo e(route('admin.informasi.destroy', $informasitoko->id)); ?>" method="POST" style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this Product?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\breeze2\resources\views/admin/informasi/informasitoko.blade.php ENDPATH**/ ?>