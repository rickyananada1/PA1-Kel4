
<?php $__env->startSection('title', 'Detail Peralatan Rumah Tangga'); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-3" style="max-width: 540px;">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="<?php echo e(asset('images/alatrt/'.$rumahtangga->image)); ?>" class="img-fluid rounded-start" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h3 class="card-title"><?php echo e($rumahtangga->name); ?></h3>
        <p class="card-text">Rp. <?php echo e(number_format($rumahtangga->harga)); ?></p>
        <br>
        <p class="card-text">Stok : <?php echo e($rumahtangga->stok); ?></p>
        <p class="card-text"><?php echo e($rumahtangga->description); ?></p>
        <p class="card-text"><small class="text-muted"><?php echo e($rumahtangga->updated_at); ?></small></p>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('client.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\breeze\resources\views/client/alatrt/show.blade.php ENDPATH**/ ?>