

<?php $__env->startSection('title', 'Peralatan Listrik'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Peralatan Listrik</h3>
            <div class="card-tools">
                <a href="<?php echo e(route('admin.alatlistrik.create')); ?>" class="btn btn-success btn-sm">Add New</a>
            </div>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $peralatanlistrik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peralatanlistrik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($peralatanlistrik->id); ?></td>
                            <td><?php echo e($peralatanlistrik->name); ?></td>
                            <td>Rp. <?php echo e(number_format($peralatanlistrik->harga, 0, ',', '.')); ?></td>
                            <td><?php echo e($peralatanlistrik->stok); ?></td>
                            <td><?php echo e($peralatanlistrik->description); ?></td>
                            <td>
                                <?php if($peralatanlistrik->image): ?>
                                    <img src="<?php echo e(asset('images/alatlistrik/'.$peralatanlistrik->image)); ?>" alt="<?php echo e($peralatanlistrik->name); ?>" width="100">
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.alatlistrik.edit', $peralatanlistrik->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                <form action="<?php echo e(route('admin.alatlistrik.destroy', $peralatanlistrik->id)); ?>" method="POST" style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this Product?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\breeze2\resources\views/admin/alatlistrik/peralatanlistrik.blade.php ENDPATH**/ ?>