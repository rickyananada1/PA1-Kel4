
<?php $__env->startSection('title','User | Peralatan Konstruksi'); ?>
<?php $__env->startSection('content'); ?>
<?php
  $peralatankonstruksis = DB::table('peralatankonstruksis')->get();
  ?>

  <?php echo $__env->make('client.section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="topics-section section-padding pb-0" id="section_3">
            <div class="container">
                <div class="row">
                  <div class="col-lg-12 col-12">
                    <div class="section-title-wrap mb-5">
                      <h4 class="section-title">Peralatan Konstruksi</h4>
                    </div>
                  </div>
                  <?php $__currentLoopData = $peralatankonstruksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                  <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                    <div class="custom-block custom-block-overlay">
                      <a href="<?php echo e(route('client.alatkonstruksi.show', $item->id)); ?>" class="custom-block-image-wrap">
                                <img src="<?php echo e(asset('images/alatkonstruksi/'.$item->image)); ?>"
                                    class="custom-block-image img-fluid" alt="">
                            </a>

                            <div class="custom-block-info custom-block-overlay-info">
                                <h5 class="mb-1">
                                    <a href="<?php echo e(route('client.alatkonstruksi.show', $item->id)); ?>">
                                    <?php echo e($item->name); ?>

                                    Rp. <?php echo e(number_format($item->harga)); ?>

                                    </a>
                                </h5>
                                <p class="badge mb-0">Stok: <?php echo e($item->stok); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <?php echo $__env->make('client.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\breeze2\resources\views/client/alatkonstruksi/peralatankonstruksi.blade.php ENDPATH**/ ?>