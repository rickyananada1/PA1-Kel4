
<?php $__env->startSection('title','User |Dashboard'); ?>
<?php $__env->startSection('content'); ?>
  
<?php
  $informasitokos = DB::table('informasitokos')->get();
  ?>


<div class="container">
  <h2>Dashboard</h2>
<?php $__currentLoopData = $informasitokos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="actu-bloc">
            <div class="actu-content">
                <div class="img-container">
                    <div class="cover-img">
                    </div>
                    <img src=" <?php echo e(asset('images/informasi/'.$item->image)); ?>" width="200px" height="150px" alt="...">
                </div>
                <div>
                    <h2><?php echo e($item->name); ?></h2>
                    <p><?php echo e($item->description); ?> </p>
                </div>

            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php $__env->stopSection(); ?>
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
<?php echo $__env->make('client.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\breeze\resources\views/client/dashboard.blade.php ENDPATH**/ ?>