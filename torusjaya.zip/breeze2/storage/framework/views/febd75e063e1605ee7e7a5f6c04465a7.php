
<?php $__env->startSection('title','User |Dashboard'); ?>
<?php $__env->startSection('content'); ?>
        <?php echo $__env->make('client.section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('client.pengumuman', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('client.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('client.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'> 
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\breeze2\resources\views/client/welcome.blade.php ENDPATH**/ ?>